
  import { initializeApp } from "https://www.gstatic.com/firebasejs/11.3.1/firebase-app.js";
  import { getDatabase, ref, set, get, child } from "https://www.gstatic.com/firebasejs/11.3.1/firebase-database.js";
 

  const firebaseConfig = {
    apiKey: "AIzaSyDxKGpwC4qLBXZwG-P8QmMglpOageoJ0Lc",
    authDomain: "softverinzinjeringprojekt.firebaseapp.com",
    projectId: "softverinzinjeringprojekt",
    storageBucket: "softverinzinjeringprojekt.firebasestorage.app",
    messagingSenderId: "1049973857413",
    appId: "1:1049973857413:web:8bb684822460d872259dec"
  };

  const app = initializeApp(firebaseConfig);

  const db = getDatabase(app);

  document.getElementById("login-button").addEventListener('click', function(e){
    set(ref(db, 'user/' + document.getElementById("username").value),{
        username: document.getElementById("username").value,
        email: document.getElementById("email").value,
        password: document.getElementById("password").value
    });
    alert("Login uspjesan!");
  })
